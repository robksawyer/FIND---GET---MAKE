<?php

/* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2: */

class AclController extends AclAppController {
	var $name = 'Acl';

	var $uses = array('Acl.AclAco', 'Acl.AclAro');

	var $helpers = array('Html', 'Javascript');

	function admin_index() {

	}

	function admin_aros() {

	}

	function admin_acos() {

	}

	function admin_permissions() {

	}

}

?>
