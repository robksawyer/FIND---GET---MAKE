<?php

/* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2: */

class AclAppModel extends Model {
	
	var $actsAs = array('Containable');	
}

?>
