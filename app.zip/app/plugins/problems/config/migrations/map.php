<?php
/**
 * Problems CakePHP Plugin
 *
 * Copyright 2010, Cake Development Corporation
 *                 1785 E. Sahara Avenue, Suite 490-423
 *                 Las Vegas, Nevada 89104
 *
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright 2010, Cake Development Corporation
 * @link      http://github.com/CakeDC/Comments
 * @package   plugins.problems.config.migrations
 * @license   MIT License (http://www.opensource.org/licenses/mit-license.php)
 */
$map = array(
	1 => array(
		'001_problems_schema' => 'M4c31fc230f2040c1821506fa0e8f3d6d'),
);
?>