<?php
App::import('Lib', 'Facebook.FacebookInfo');
class FacebookAppController extends AppController {

}
?>