<?php
class BetaUser extends AppModel {
	var $name = 'BetaUser';
}