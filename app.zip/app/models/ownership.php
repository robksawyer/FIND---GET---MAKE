<?php
/**
 * Currently only products can be owned or wanted.
 */
class Ownership extends AppModel {
	var $name = 'Ownership';
  
	var $validate = array('user_id' => array('rule' => array('maxLength', 36),
										   'required' => true),
						'model_id' => array('rule' => array('maxLength', 36),
											'required' => true),
						'model' => array('rule' => 'alphaNumeric',
										 'required' => true));
										
	var $belongsTo = array(	'User' => array(
								'className' => 'User',
								'foreignKey' => 'user_id',
								'conditions' => '',
								'fields' => '',
								'order' => ''
							),
							'Product' => array(
								'className' => 'Product',
								'foreignKey' => 'model_id',
								'fields' => '',
								'order' => ''
							)
							);

	var $hasMany = array(
		'Feed' => array(
			'className' => 'Feed',
			'foreignKey' => 'model_id',
			'conditions' => array('Feed.model' => 'Ownership'),
			'dependent' => true,
			'exclusive' => true
		)
	);
	
	/**
	 * BUG: This is not firing when using AJAX calls. This is handled in the controller.
	 * Updates the total count in the user table for this particular type of item
	 * @param created 
	 * @return 
	 * 
	*/	
	/*public function afterSave($created){
		if($created){
			//Update the total count for the user
			$last = $this->read(null,$this->id);
			if(!empty($last['User']['id'])){
				//Add the feed data to the feed
				$this->Feed->addFeedData('Ownership',$last);
			}
		}
	}*/
	
	/**
	 * Returns the needed feed data for a specific record
	 * @param int model_id
	 * @return 
	 * 
	*/
	public function getFeedData($model_id=null){
		$this->recursive = 0;
		$data = $this->read(null,$model_id);
		if(!empty($data['Product']['id'])){
			$product = $this->Product->read(null,$data['Product']['id']);
			$data['Product'] = $product;
		}
		return $data;
	}
	
	/**
	 * Return the first item found based on the passed data
	 * @param user_id
	 * @param model
	 * @param model_id
	 * @return 
	 * 
	*/
	function getFirst($user_id=null,$model=null,$model_id=null){
		$data = $this->find('first',array('conditions'=>array(
															"Ownership.model_id"=>$model_id,
															'Ownership.user_id'=>$user_id,
															'Ownership.model'=>$model
															)
														));
		return $data;
	}
	
	
	// =================================
	// = Returns only the total counts =
	// =================================
	
	/**
	 * This method returns the total number of people who have a particular item.
	 * @param model
	 * @param model_id
	 * @return data
	 * 
	*/
	function getHaveCount($model=null,$model_id=null){
		$data = $this->find('count',array('conditions'=>array(
															'have_it'=>1,
															"model_id"=>$model_id,
															"model"=>$model
															)));
		//debug($data);
		return $data;
	}
	/**
	 * This method returns the total number of people who want a particular item.
	 * @param model
	 * @param model_id
	 * @return data
	 * 
	*/
	function getWantCount($model=null,$model_id=null){
		$data = $this->find('count',array('conditions'=>array(
															'want_it'=>1,
															"model_id"=>$model_id,
															"model"=>$model
															)));
		//debug($data);
		return $data;
	}
	/**
	 * This method returns the total number of people who had a particular item.
	 * @param model
	 * @param model_id
	 * @return data
	 * 
	*/
	function getHadCount($model=null,$model_id=null){
		$data = $this->find('count',array('conditions'=>array(
															'had_it'=>1,
															"model_id"=>$model_id,
															"model"=>$model
															)));
		return $data;
	}
	
	
	// =============================
	// = Returns entire User array =
	// =============================
	/**
	 * This method returns the details of people who have a particular item.
	 * @param model
	 * @param model_id
	 * @return data
	 * 
	*/
	function getHaveUsers($model=null,$model_id=null){
		$data = $this->find('all',array('conditions'=>array(
															'have_it'=>1,
															"model_id"=>$model_id,
															'model'=>$model
															),
										'contain'=>array('User'=>array('Product'=>array('Attachment',
																						'limit'=>3,
																						'order'=>array('Product.created'=>'desc')
																						)))
										));
		//return $this->_parseOwnershipInfo($data);
		return $data;
	}
	
	/**
	 * This method returns the details of people who want a particular item.
	 * @param model
	 * @param model_id
	 * @return data
	 * 
	*/
	function getWantUsers($model=null,$model_id=null){
		$data = $this->find('all',array('conditions'=>array(
															'want_it'=>1,
															"model_id"=>$model_id,
															'model'=>$model
															),
										'contain'=>array('User'=>array('Product'=>array('Attachment',
																						'limit'=>3,
																						'order'=>array('Product.created'=>'desc')
																						)))
										));
		//return $this->_parseOwnershipInfo($data);
		return $data;
	}
	
	/**
	 * This method returns the details of people who had a particular item.
	 * @param model
	 * @param model_id
	 * @return data
	 * 
	*/
	function getHadUsers($model=null,$model_id=null){
		$data = $this->find('all',array('conditions'=>array(
															'had_it'=>1,
															"model_id"=>$model_id,
															'model'=>$model
															),
										'contain'=>array('User'=>array('Product'=>array('Attachment','limit'=>3)))
										));
		//return $this->_parseOwnershipInfo($data);
		return $data;
	}
	
	
	/**
	 * This method returns the wants of a particular user
	 * @param string model The model to target
	 * @param int user_id The user id to target
	 * @return data
	 * 
	*/
	function getUserWants($model=null,$user_id=null){
		$data = $this->find('all',array('conditions'=>array(
															'want_it'=>1,
															"Ownership.user_id"=>$user_id,
															'model'=>$model
															),
										'contain'=>array('Product'=>array('Attachment'))	
										));
		return $data;
	}
	
	/**
	 * This method returns the haves of a particular user
	 * @param string model The model to target
	 * @param int user_id The user id to target
	 * @return data
	 * 
	*/
	function getUserHaves($model=null,$user_id=null){
		$data = $this->find('all',array('conditions'=>array(
															'have_it'=>1,
															"Ownership.user_id"=>$user_id,
															'model'=>$model
															),
										'contain'=>array('Product'=>array('Attachment'))	
										));
		return $data;
	}
	
	/**
	 * This method returns the wants of a particular user
	 * @param string model The model to target
	 * @param int user_id The user id to target
	 * @return data
	 * 
	*/
	function getUserWantCount($model=null,$user_id=null){
		$data = $this->find('count',array('conditions'=>array(
															'want_it'=>1,
															"Ownership.user_id"=>$user_id,
															'model'=>$model
															)));
		return $data;
	}
	
	/**
	 * This method returns the haves of a particular user
	 * @param string model The model to target
	 * @param int user_id The user id to target
	 * @return data
	 * 
	*/
	function getUserHaveCount($model=null,$user_id=null){
		$data = $this->find('count',array('conditions'=>array(
															'have_it'=>1,
															"Ownership.user_id"=>$user_id,
															'model'=>$model
															)));
		return $data;
	}
	
	/**
	 * Sets the ownership status of an item to want
	 * @param int user_id
	 * @param string model 
	 * @param int model_id
	 * @return 
	 * 
	*/
	public function setWant($user_id=null,$model=null,$model_id=null){
		Configure::write('debug', 2);
		$type="want_it";
		$type_niceName = "want";
		$controller = Inflector::pluralize(strtolower($model));
		$data = $this->getFirst($user_id,$model,$model_id);
		//Make sure the user only has one want it, had it, or have it.
		if(!empty($data)){
			//Update an existing ownership for this user
			$this->read(null,$data['Ownership']['id']);
			
			foreach($ownership_types as $ownership_type){
				if($type == $ownership_type){
					$this->set(array(
									'name' => $controller,
									'model' => $model,
									'model_id' => $model_id,
									$ownership_type => 1
									)
								);
				}else{
					$this->set(array(
									$ownership_type => 0
									)
								);
				}
			}
			
			if($this->save()){
				//The save was successful
				
				//Send a notification email
				//$this->send_email_on_product_have_want($model_id,$type_niceName);
				
			}else{
				return;
			}

		}else{
			//Create a new ownership for this user
			$this->create();
			$this->set(array(
							'user_id' => $user_id,
							'model' => $model,
							'model_id' => $model_id,
							'name' => $controller
							)
						);
			
			$this->set($type, 1);
			
			if($this->save()){
				//The save was successful
				
				//Send a notification email
				//$this->send_email_on_product_have_want($model_id,$type_niceName);
				
			}else{
				return;
			}
		}
		
		if(!empty($data['Ownership']['id'])){
			$last = $this->read(null,$data['Ownership']['id']);
		}else{
			$last = $this->read(null,$this->getLastInsertID());
		}
		$this->Feed->addFeedData('Ownership',$last);
		return;
	}
	
	/**
	 * Parses the user id from the Ownership table and returns more of the user's info
	 * @param data
	 * @return userData
	 * 
	*/
	function _parseOwnershipInfo($data=null){
		//$this->User->recursive = -1; //Just find the user data. Set this higher to get more info
		$userData = array();
		if(!empty($data)){
			foreach($data as $user){
				//Find the user data from the user_id
				$the_user = $this->User->read(null,$user['Ownership']['user_id']);
				if(!empty($the_user)) $userData[] = $the_user;
			}
		}
		
		return $userData;
	}
	
	/**
	 * Parse the owner array and return the ownership type
	 * Example:
	 * return have it
	 * return want it
	 * return had it
	 * @param int user_id
	 * @param string model
	 * @param int model_id
	 * @return String type
	 * 
	*/
	function getOwnershipType($user_id=null,$model=null,$model_id=null){
		$data = $this->find('first',array(
										'conditions'=>array(
											'Ownership.user_id'=>$user_id,
											"model"=>$model,
											"model_id"=>$model_id
											)));
														
		if($data['Ownership']['have_it']){
			return 'have_it';
		}else if($data['Ownership']['want_it']){
			return 'want_it';
		}else if($data['Ownership']['had_it']){
			return 'had_it';
		}else{
			return null;
		}
	}
}