<?php
/**
 * Tools 
 */
class Tool extends AppModel {
	
	var $name = 'Tool';
	var $useTable = false;
	
}