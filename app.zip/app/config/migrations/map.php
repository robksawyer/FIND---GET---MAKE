<?php
$map = array(
	1 => array(
		'find_get_make_base' => 'M4e76d35f552c43718ba3e2d08bbe252e'),
	2 => array(
		'find_get_make_all' => 'M4e76d41d4a144e4d8623e3638bbe252e'),
	3 => array(
		'find_get_make_base' => 'M4e76d4aee0944b7d90d0e3d58bbe252e'),
	4 => array(
		'find_get_make_all' => 'M4e76d4cbf3a44baaae36e3ef8bbe252e'),
);
?>